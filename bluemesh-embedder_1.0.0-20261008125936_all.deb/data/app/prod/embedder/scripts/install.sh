#!/usr/bin/env bash
# install.sh — install the BlueMesh Embedder Service on this machine.
#
# Usage: sudo ./scripts/install.sh [install-dir] [--hf-token TOKEN]
#   --hf-token (or HF_TOKEN in the environment; asked for when interactive) is validated
#   against huggingface.co and stored root-only in /etc/bluemesh/hf.env. An invalid or
#   expired token stops the install. Without one, public models still download anonymously.
set -euo pipefail

INSTALL_DIR="/data/app/prod/embedder"
HF_TOKEN="${HF_TOKEN:-}"
while [[ $# -gt 0 ]]; do
    case "$1" in
        --hf-token) HF_TOKEN="${2:?--hf-token needs a value}"; shift ;;
        *) INSTALL_DIR="$1" ;;
    esac
    shift
done
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(dirname "$SCRIPT_DIR")"

[[ $EUID -ne 0 ]] && { echo "Run as root (sudo)." >&2; exit 1; }

# Hugging Face token — checked BEFORE anything is installed, so a bad token changes nothing.
if [[ -z "$HF_TOKEN" && -t 0 ]]; then
    read -rsp "Hugging Face token (blank = anonymous): " HF_TOKEN; echo
fi
if [[ -n "$HF_TOKEN" ]]; then
    [[ "$HF_TOKEN" == hf_* ]] || { echo "❌ HF token must start with hf_" >&2; exit 1; }
    command -v curl >/dev/null || { echo "❌ curl is required to validate the HF token" >&2; exit 1; }
    code=$(curl -s -o /dev/null -m 20 -w '%{http_code}' -H "Authorization: Bearer $HF_TOKEN" \
           https://huggingface.co/api/whoami-v2 || true)
    case "$code" in
        200) echo "✅ HF token valid" ;;
        401) echo "❌ HF token rejected by huggingface.co (invalid or expired) — install stopped" >&2; exit 1 ;;
        *)   echo "❌ could not validate the HF token (HTTP ${code:-none}) — check network; install stopped" >&2; exit 1 ;;
    esac
    install -d -m 700 /etc/bluemesh
    (umask 077; printf 'HF_TOKEN=%s\n' "$HF_TOKEN" > /etc/bluemesh/hf.env)
    echo "🔐 HF token stored in /etc/bluemesh/hf.env (root-only)"
fi

echo "Installing BlueMesh Embedder → $INSTALL_DIR"

mkdir -p "$INSTALL_DIR"
# When the install dir IS the source tree, there is nothing to sync and rsync would
# copy the tree onto itself. That is the normal shape for a hardened release: the
# install dir is a CLONE of the release repo (see RELEASE.md), which is what lets
# scripts/upgrade.sh be a plain `git pull` + restart.
if [[ "$(cd "$SRC_DIR" && pwd)" != "$(cd "$INSTALL_DIR" && pwd)" ]]; then
    rsync -a --exclude='.git' --exclude='.venv' --exclude='__pycache__' \
             --exclude='*.pyc' "$SRC_DIR/" "$INSTALL_DIR/"
else
    echo "Install dir is the source tree (release-repo clone) — skipping sync."
fi

if ! command -v uv &>/dev/null; then
    echo "Installing uv..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    # current uv installs to ~/.local/bin (older releases used ~/.cargo/bin)
    export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"
fi

echo "Installing dependencies with uv..."
uv venv "$INSTALL_DIR/.venv" --python 3.11
uv pip install --python "$INSTALL_DIR/.venv/bin/python" \
    -r <(uv export --no-hashes --project "$INSTALL_DIR" 2>/dev/null) \
    || uv pip install --python "$INSTALL_DIR/.venv/bin/python" \
        --project "$INSTALL_DIR" -e "$INSTALL_DIR"

echo "Dependencies installed."

UNIT="/etc/systemd/system/bluemesh-embedder.service"
sed "s|/data/app/prod/embedder|$INSTALL_DIR|g" \
    "$INSTALL_DIR/bluemesh-embedder.service" > "$UNIT"
systemctl daemon-reload
systemctl enable bluemesh-embedder
echo "Systemd unit installed and enabled."
echo ""
echo "Start: systemctl start bluemesh-embedder"
echo "Logs:  journalctl -u bluemesh-embedder -f"

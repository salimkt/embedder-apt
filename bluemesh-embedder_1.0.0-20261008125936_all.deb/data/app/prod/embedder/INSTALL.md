# Installing bluemesh-embedder

An apt-installable build of the BlueMesh embedder service. The service's own modules ship as
compiled CPython extensions, not readable Python.

## Two ways to install

**From the apt repository** — the normal path; later releases arrive with `apt upgrade`:

```bash
echo 'deb [trusted=yes] https://raw.githubusercontent.com/salimkt/embedder-apt/main ./' | sudo tee /etc/apt/sources.list.d/bluemesh.list
sudo apt update
sudo apt install bluemesh-embedder
```

**From a downloaded .deb** — air-gapped hosts, or pinning one specific build:

```bash
sudo apt install ./bluemesh-embedder_1.0.0_all.deb
```

Either way, then:

```bash
sudo systemctl start bluemesh-embedder
curl -fsS http://127.0.0.1:8252/embedder/health
```

That is the whole install. The rest of this file is what to do when something is not standard.

## Requirements

| | |
|---|---|
| OS | Debian 12 / Ubuntu 22.04+ (anything with systemd and dpkg) |
| CPU | x86_64 **or** aarch64 — one package covers both |
| Python | **3.11 3.12** — must already be on the host (`python3.11` or `python3.12`) |
| Network | needed once, at install, to download the Python dependencies |

The package is `Architecture: all` but still contains native code. That works because a
CPython extension's filename encodes its platform and interpreter
(`app.cpython-312-aarch64-linux-gnu.so`), and each interpreter loads only its own. One
artifact therefore installs correctly on an x86 server and on an ARM box such as an NVIDIA DGX.

**The Python version is not negotiable.** A venv on 3.10 or 3.13 will not see the modules at
all, and reports it as `ModuleNotFoundError: No module named 'config'` — see Troubleshooting.

## What it does at install time

1. Unpacks the service to `/data/app/prod/embedder`.
2. Registers `/lib/systemd/system/bluemesh-embedder.service` (port 8252) and **enables** it.
3. Runs `bluemesh-embedder-setup`, which creates `/data/app/prod/embedder/.venv` and installs the
   pinned dependencies from `requirements.txt`.

It does **not start the service**. Startup loads the model, which on a cold host means a
multi-GB download; that should be your decision, not a side effect of `apt install`.

If the dependency step fails (no network, proxy, mirror down) **the package still installs** —
a half-configured package would block every later apt operation. Finish it with:

```bash
sudo bluemesh-embedder-setup
```

## Running it

```bash
sudo systemctl start bluemesh-embedder      # start
sudo systemctl status bluemesh-embedder     # state
journalctl -u bluemesh-embedder -f          # logs
```

systemd runs `/data/app/prod/embedder/scripts/run.sh`, which resolves the venv, puts the install
directory on `PYTHONPATH` (the compiled modules are imported from there) and `exec`s the
server so systemd tracks the real PID. You can run the same script by hand to see startup
output directly.

## Configuration

Edit `/data/app/prod/embedder/settings.yml`, then `sudo systemctl restart bluemesh-embedder`.

It is registered as a dpkg **conffile**, so your edits survive upgrades: dpkg keeps your
version and asks what to do if the packaged default has also changed.

## Upgrading

```bash
sudo apt update
sudo apt upgrade                       # or: sudo apt install --only-upgrade bluemesh-embedder
sudo systemctl restart bluemesh-embedder
```

Every published build carries a UTC-timestamped Debian revision
(`1.0.0-20260910180000`), because apt decides by **version comparison** — republishing the
same `1.0.0` would be invisible to it. A real version bump still wins over any revision, so
`1.0.1-<older timestamp>` correctly supersedes `1.0.0-<newer timestamp>`.

Older versions stay in the archive, so you can pin or roll back:

```bash
apt-cache madison bluemesh-embedder                       # what is available
sudo apt install bluemesh-embedder=1.0.0-20260910120000   # go back to a specific build
```

If the new build's `requirements.txt` changed, refresh the venv:

```bash
sudo bluemesh-embedder-setup && sudo systemctl restart bluemesh-embedder
```

Your `settings.yml` is a dpkg conffile, so upgrades keep your edits and dpkg asks before
replacing it if the packaged default also changed.

## Removing

```bash
sudo apt remove bluemesh-embedder     # stops + disables; removes the .so and the unit
sudo apt purge  bluemesh-embedder     # additionally deletes settings.yml, the venv, the directory
```

Measured behaviour:

| | `apt remove` | `apt purge` |
|---|---|---|
| compiled modules, unit | removed | removed |
| `settings.yml` | **kept** (conffile) | removed |
| `.venv` (and downloaded models) | **kept** | removed |
| `/data/app/prod/embedder` | kept | removed |

`remove` leaves the package in dpkg's `rc` state, so reinstalling later reuses your config
and your already-downloaded dependencies.

## Troubleshooting

**`ModuleNotFoundError: No module named 'config'`** — the commonest failure, and it is not a
missing file. Python found no extension matching *this* interpreter. Diagnose with:

```bash
cd /data/app/prod/embedder && ./scripts/run.sh
```

It prints what the build shipped against what you are running, for example:

```
[run] ERROR: this build's compiled modules cannot be imported by this interpreter.
[run]   built for   : platform=linux/amd64 python=3.11 3.12
[run]   running on  : linux/x86_64 python=3.10
```

Fix by recreating the venv on a supported interpreter:

```bash
sudo rm -rf /data/app/prod/embedder/.venv && sudo bluemesh-embedder-setup
```

**The service starts but nothing answers** — on first start it downloads its model; watch
`journalctl -u bluemesh-embedder -f`. `TimeoutStartSec` may need raising on a slow link.

**Which build am I running?** `cat /data/app/prod/embedder/BUILD` — version, source commit,
platforms and interpreters. `HARDEN-*.log` shows which modules were compiled.

## Layout

| path | |
|---|---|
| `/data/app/prod/embedder/` | the service (`.so`, `main.py`, `settings.yml`, `scripts/`) |
| `/data/app/prod/embedder/.venv` | dependencies — created by setup, not owned by dpkg |
| `/lib/systemd/system/bluemesh-embedder.service` | the unit |
| `/usr/bin/bluemesh-embedder-setup` | re-create the venv |

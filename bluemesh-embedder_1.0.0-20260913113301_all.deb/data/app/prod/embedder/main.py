"""Entry point — start uvicorn using values from settings.yml / env vars."""
import uvicorn
from config import svc

if __name__ == "__main__":
    uvicorn.run(
        "app:app",
        host=svc.HOST,
        port=svc.PORT,
        workers=svc.WORKERS,
        log_level=svc.LOG_LEVEL,
        loop="uvloop",
        http="httptools",
        access_log=True,
    )

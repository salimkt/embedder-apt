#!/usr/bin/env bash
set -euo pipefail
sudo systemctl stop bluemesh-embedder && echo "bluemesh-embedder stopped."

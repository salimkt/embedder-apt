#!/usr/bin/env bash
# install.sh — install the BlueMesh Embedder Service on this machine.
set -euo pipefail

INSTALL_DIR="${1:-/data/app/prod/embedder}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(dirname "$SCRIPT_DIR")"

[[ $EUID -ne 0 ]] && { echo "Run as root (sudo)." >&2; exit 1; }

echo "Installing BlueMesh Embedder → $INSTALL_DIR"

mkdir -p "$INSTALL_DIR"
# When the install dir IS the source tree, there is nothing to sync and rsync would
# copy the tree onto itself. That is the normal shape for a hardened release: the
# install dir is a CLONE of the release repo (see RELEASE.md), which is what lets
# scripts/upgrade.sh be a plain `git pull` + restart.
if [[ "$(cd "$SRC_DIR" && pwd)" != "$(cd "$INSTALL_DIR" && pwd)" ]]; then
    rsync -a --exclude='.git' --exclude='.venv' --exclude='__pycache__' \
             --exclude='*.pyc' "$SRC_DIR/" "$INSTALL_DIR/"
else
    echo "Install dir is the source tree (release-repo clone) — skipping sync."
fi

if ! command -v uv &>/dev/null; then
    echo "Installing uv..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    # current uv installs to ~/.local/bin (older releases used ~/.cargo/bin)
    export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"
fi

echo "Installing dependencies with uv..."
uv venv "$INSTALL_DIR/.venv" --python 3.11
uv pip install --python "$INSTALL_DIR/.venv/bin/python" \
    -r <(uv export --no-hashes --project "$INSTALL_DIR" 2>/dev/null) \
    || uv pip install --python "$INSTALL_DIR/.venv/bin/python" \
        --project "$INSTALL_DIR" -e "$INSTALL_DIR"

echo "Dependencies installed."

UNIT="/etc/systemd/system/bluemesh-embedder.service"
sed "s|/data/app/prod/embedder|$INSTALL_DIR|g" \
    "$INSTALL_DIR/bluemesh-embedder.service" > "$UNIT"
systemctl daemon-reload
systemctl enable bluemesh-embedder
echo "Systemd unit installed and enabled."
echo ""
echo "Start: systemctl start bluemesh-embedder"
echo "Logs:  journalctl -u bluemesh-embedder -f"

#!/usr/bin/env bash
journalctl -u bluemesh-embedder -f

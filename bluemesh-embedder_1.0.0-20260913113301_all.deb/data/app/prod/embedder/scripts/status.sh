#!/usr/bin/env bash
sudo systemctl status bluemesh-embedder --no-pager
echo ""
curl -sf http://localhost:8252/embedder/health | python3 -m json.tool 2>/dev/null || echo "Service not responding on port 8252"

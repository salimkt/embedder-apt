#!/usr/bin/env bash
set -euo pipefail
sudo systemctl restart bluemesh-embedder
sudo systemctl status bluemesh-embedder --no-pager
journalctl -u bluemesh-embedder -f
